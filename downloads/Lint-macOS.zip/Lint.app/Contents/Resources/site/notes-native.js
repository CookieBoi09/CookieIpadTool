(() => {
  // site/notes/model.js
  var KEY = "lint.web.notes.v1";
  var WIDTH = 1e3;
  var HEIGHT = 620;
  var COLORS = [
    "#253428",
    "#3565b9",
    "#b34b4b",
    "#577848",
    "#f0ca48",
    "#e9a2bb"
  ];
  var uid = () => crypto.randomUUID();
  var emptyLibrary = () => ({
    format: "lint-notes",
    version: 1,
    folders: [],
    notes: []
  });
  function makeNote(folderId = null) {
    return {
      id: uid(),
      folderId,
      title: "Untitled note",
      text: "",
      strokes: [],
      ...globalThis.lintNative?.platform === "macOS" ? { pageHeight: 1400 } : {},
      created: Date.now(),
      updated: Date.now()
    };
  }
  function validate(value) {
    const fail = () => {
      throw new Error(
        "This is not a valid Lint notes backup. Existing notes have not been replaced."
      );
    };
    if (!value || value.format !== "lint-notes" || value.version !== 1 || !Array.isArray(value.folders) || !Array.isArray(value.notes))
      fail();
    for (const items of [value.folders, value.notes]) {
      if (items.some((x) => !x || typeof x.id !== "string" || !x.id) || new Set(items.map((x) => x.id)).size !== items.length)
        fail();
    }
    const folders = new Map(value.folders.map((f) => [f.id, f]));
    for (const folder of value.folders) {
      if (typeof folder.name !== "string" || !folder.name.trim()) fail();
      const visited = /* @__PURE__ */ new Set([folder.id]);
      let parent = folder.parentId;
      while (parent !== null) {
        if (!folders.has(parent) || visited.has(parent)) fail();
        visited.add(parent);
        parent = folders.get(parent).parentId;
      }
    }
    let pointCount = 0;
    for (const note2 of value.notes) {
      if (note2.folderId !== null && !folders.has(note2.folderId) || typeof note2.title !== "string" || !note2.title.trim() || typeof note2.text !== "string" || !Number.isFinite(note2.created) || !Number.isFinite(note2.updated) || note2.pageHeight !== void 0 && ![620, 1400].includes(note2.pageHeight) || !Array.isArray(note2.strokes))
        fail();
      for (const stroke of note2.strokes) {
        if (!stroke || !["pen", "highlighter"].includes(stroke.tool) || !COLORS.includes(stroke.color) || !Number.isFinite(stroke.width) || stroke.width < 1 || stroke.width > 48 || !Array.isArray(stroke.points) || !stroke.points.length)
          fail();
        for (const point of stroke.points) {
          if (!Array.isArray(point) || point.length !== 2 || !point.every(Number.isFinite) || point[0] < 0 || point[0] > WIDTH || point[1] < 0 || point[1] > (note2.pageHeight || HEIGHT))
            fail();
          if (++pointCount > 2e5)
            throw new Error(
              "This notes library has too many drawing points. Split it into smaller backups."
            );
        }
      }
    }
    return value;
  }
  function removeFolder(library2, id) {
    const parent = library2.folders.find((f) => f.id === id)?.parentId ?? null;
    library2.folders = library2.folders.filter((f) => f.id !== id).map((f) => f.parentId === id ? { ...f, parentId: parent } : f);
    library2.notes.forEach((n) => {
      if (n.folderId === id) n.folderId = parent;
    });
  }
  function folderPath(library2, id) {
    const names = [];
    let folder = library2.folders.find((f) => f.id === id);
    while (folder) {
      names.unshift(folder.name);
      folder = library2.folders.find((f) => f.id === folder.parentId);
    }
    return names.join(" / ") || "Notes";
  }

  // site/notes/native-mapping.js
  function cursorRegion(point, pageWidth, pageHeight, width2 = 400, height = 250) {
    width2 = Math.min(width2, pageWidth);
    height = Math.min(height, pageHeight);
    return { x: Math.max(0, Math.min(pageWidth - width2, point[0] - width2 / 2)), y: Math.max(0, Math.min(pageHeight - height, point[1] - height / 2)), width: width2, height };
  }
  function mapTouch(frame, region, inset = 0) {
    if (!frame || !["begin", "move"].includes(frame.phase) || !Number.isFinite(frame.x) || !Number.isFinite(frame.y) || frame.x < 0 || frame.x > 1 || frame.y < 0 || frame.y > 1) return null;
    const margin = Math.min(Math.max(0, inset), region.width / 2, region.height / 2);
    return [region.x + margin + frame.x * (region.width - 2 * margin), region.y + margin + frame.y * (region.height - 2 * margin)].map((n) => Math.round(n * 10) / 10);
  }

  // site/notes/native-drawing.js
  function attachNativeDrawing(svg, { getNote, getTool, changed: changed2, status, active, makePath }) {
    const bridge2 = window.lintNative;
    let native = true, space = false, current = null, path = null, last = null, region = null, waiting;
    const box = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    box.setAttribute("class", "native-trackpad-region");
    box.setAttribute("pointer-events", "none");
    box.setAttribute("fill", "none");
    box.setAttribute("stroke", "#617e44");
    box.setAttribute("stroke-width", "2");
    box.setAttribute("stroke-dasharray", "5 7");
    box.style.display = "none";
    svg.append(box);
    const controls = document.createElement("div");
    controls.className = "native-trackpad-controls";
    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.textContent = "Trackpad positioning: on";
    toggle.setAttribute("aria-pressed", "true");
    const hint = document.createElement("span");
    hint.setAttribute("role", "status");
    hint.textContent = "Position the dotted rectangle. Hold Space, then place one finger on the trackpad.";
    controls.append(toggle, hint);
    svg.parentElement.before(controls);
    bridge2.setEnabled(true);
    const editable = (target) => target instanceof Element && !!target.closest('input,textarea,select,button,a,[contenteditable="true"]');
    function point(event) {
      const r = svg.getBoundingClientRect();
      const v = svg.viewBox.baseVal;
      const x = (event.clientX - r.left) / r.width * v.width, y = (event.clientY - r.top) / r.height * v.height;
      return x >= 0 && x <= v.width && y >= 0 && y <= v.height ? [x, y] : null;
    }
    function position(p) {
      const v = svg.viewBox.baseVal;
      region = cursorRegion(p, v.width, v.height);
      for (const [key, value] of Object.entries(region)) box.setAttribute(key, value);
      box.style.display = "";
    }
    function finish() {
      if (current) {
        current = null;
        path = null;
        changed2();
      }
    }
    function disarm(notify = true) {
      space = false;
      clearTimeout(waiting);
      finish();
      svg.classList.remove("writing");
      status(false);
      if (notify) bridge2.setArmed(false);
    }
    function add(p) {
      if (!current) {
        current = { ...getTool(), points: [p] };
        getNote().strokes.push(current);
        path = makePath(current);
        svg.append(path);
        svg.append(box);
      } else {
        const previous = current.points.at(-1);
        if (Math.hypot(p[0] - previous[0], p[1] - previous[1]) < 0.6) return;
        current.points.push(p);
        path.setAttribute("d", `M${current.points.map((p2) => p2.join(" ")).join(" L")}`);
      }
    }
    function move(event) {
      if (!active() || event.pointerType === "touch") return;
      const p = point(event);
      if (space) {
        if (!native) {
          if (p && region && p[0] >= region.x && p[0] <= region.x + region.width && p[1] >= region.y && p[1] <= region.y + region.height) add(p);
          else finish();
        }
        return;
      }
      last = p;
      if (p) position(p);
      else box.style.display = "none";
    }
    function down(event) {
      if (active() && event.pointerType !== "touch" && event.button === 0) {
        svg.focus({ preventScroll: true });
        last = point(event);
        if (last) position(last);
      }
    }
    function keydown(event) {
      if (!active() || editable(event.target) || document.querySelector("dialog[open]") || event.code !== "Space" || event.metaKey || event.ctrlKey || event.altKey || !last) return;
      event.preventDefault();
      if (space) return;
      space = true;
      position(last);
      svg.classList.add("writing");
      status(true);
      if (native) {
        bridge2.setArmed(true);
        hint.textContent = "Rectangle locked. Place one finger on the trackpad; lift it between strokes.";
        waiting = setTimeout(() => {
          if (space && !current) hint.textContent = "No touch received. Lift your finger and touch again inside Lint, or turn trackpad positioning off for cursor drawing.";
        }, 2500);
      } else add(last);
    }
    function keyup(event) {
      if (event.code === "Space") disarm();
    }
    function frame(event) {
      const data = event.detail;
      if (!data || typeof data !== "object") return;
      if (data.type === "released") {
        disarm(false);
        return;
      }
      if (data.type === "scroll") {
        finish();
        return;
      }
      if (!space || !native || !active() || !region || data.type !== "touch") return;
      if (data.phase === "end") {
        finish();
        return;
      }
      const p = mapTouch(data, region, getTool().width / 2);
      if (!p) {
        finish();
        return;
      }
      clearTimeout(waiting);
      if (data.phase === "begin") finish();
      hint.textContent = "Drawing from absolute finger position. Release Space to reposition.";
      add(p);
    }
    function focus(event) {
      if (editable(event.target) || !svg.contains(event.target)) disarm();
    }
    function visibility() {
      if (document.hidden) disarm();
    }
    function blur() {
      disarm();
      last = null;
    }
    function wheel() {
      finish();
      if (!space) {
        last = null;
        box.style.display = "none";
      }
    }
    toggle.onclick = () => {
      disarm();
      native = !native;
      bridge2.setEnabled(native);
      toggle.textContent = `Trackpad positioning: ${native ? "on" : "off"}`;
      toggle.setAttribute("aria-pressed", String(native));
      hint.textContent = native ? "Hold Space, then place one finger on the trackpad." : "Cursor fallback: hold Space and move the pointer inside the locked rectangle.";
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("keydown", keydown);
    window.addEventListener("keyup", keyup);
    window.addEventListener("blur", blur);
    window.addEventListener("pointercancel", blur);
    window.addEventListener("wheel", wheel, { passive: true });
    window.addEventListener("lint-native-trackpad", frame);
    document.addEventListener("focusin", focus);
    document.addEventListener("visibilitychange", visibility);
    svg.addEventListener("pointerdown", down);
    return { finish: () => disarm(), destroy() {
      disarm();
      bridge2.setEnabled(false);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("keydown", keydown);
      window.removeEventListener("keyup", keyup);
      window.removeEventListener("blur", blur);
      window.removeEventListener("pointercancel", blur);
      window.removeEventListener("wheel", wheel);
      window.removeEventListener("lint-native-trackpad", frame);
      document.removeEventListener("focusin", focus);
      document.removeEventListener("visibilitychange", visibility);
      svg.removeEventListener("pointerdown", down);
      box.remove();
      controls.remove();
    } };
  }

  // site/notes/drawing.js
  var NS = "http://www.w3.org/2000/svg";
  function pointInBoard(event, svg) {
    const rect = svg.getBoundingClientRect();
    if (!rect.width || !rect.height) return null;
    const x = (event.clientX - rect.left) / rect.width * WIDTH;
    const pageHeight = svg.viewBox?.baseVal.height || HEIGHT;
    const y = (event.clientY - rect.top) / rect.height * pageHeight;
    return x >= 0 && x <= WIDTH && y >= 0 && y <= pageHeight ? [Math.round(x * 10) / 10, Math.round(y * 10) / 10] : null;
  }
  function strokeElement(stroke) {
    const path = document.createElementNS(NS, "path");
    const points = stroke.points;
    const d = points.length === 1 ? `M${points[0].join(" ")} l0.01 0` : `M${points.map((p) => p.join(" ")).join(" L")}`;
    for (const [name, value] of Object.entries({
      d,
      fill: "none",
      stroke: stroke.color,
      "stroke-width": stroke.width,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      opacity: stroke.tool === "highlighter" ? 0.3 : 1,
      "data-tool": stroke.tool
    }))
      path.setAttribute(name, String(value));
    return path;
  }
  function attachDrawing(svg, { getNote, getTool, changed: changed2, status, active }) {
    if (window.lintNative?.platform === "macOS") return attachNativeDrawing(svg, { getNote, getTool, changed: changed2, status, active, makePath: strokeElement });
    let space = false, penPointer = null, current = null, path = null, lastPointer = null;
    const editable = (target) => target instanceof Element && !!target.closest('input,textarea,select,button,a,[contenteditable="true"]');
    function finish() {
      if (current) {
        current = null;
        path = null;
        changed2();
      }
    }
    function disarm() {
      space = false;
      penPointer = null;
      lastPointer = null;
      finish();
      svg.classList.remove("writing");
      status(false);
    }
    function add(point) {
      const note2 = getNote();
      if (!note2) return;
      if (!current) {
        current = { ...getTool(), points: [point] };
        note2.strokes.push(current);
        path = strokeElement(current);
        svg.append(path);
      } else {
        const previous = current.points.at(-1);
        if (Math.hypot(point[0] - previous[0], point[1] - previous[1]) < 0.8)
          return;
        current.points.push(point);
        path.setAttribute(
          "d",
          `M${current.points.map((p) => p.join(" ")).join(" L")}`
        );
      }
    }
    function move(event) {
      if (!active()) return;
      if (event.pointerType === "touch") return;
      const point = pointInBoard(event, svg);
      lastPointer = point;
      if (!space && event.pointerId !== penPointer) return;
      if (!point) {
        finish();
        return;
      }
      const samples = event.getCoalescedEvents?.() || [];
      for (const sample of samples.length ? samples : [event]) {
        const p = pointInBoard(sample, svg);
        if (p) add(p);
        else finish();
      }
    }
    function keydown(event) {
      if (!active() || document.querySelector("dialog[open]") || editable(event.target) || event.code !== "Space" || event.ctrlKey || event.altKey || event.metaKey)
        return;
      event.preventDefault();
      if (space) return;
      space = true;
      svg.classList.add("writing");
      status(true);
      if (lastPointer) add(lastPointer);
    }
    function keyup(event) {
      if (event.code === "Space") disarm();
    }
    function down(event) {
      if (!active() || event.pointerType === "touch") return;
      if (event.button !== 0) return;
      svg.focus({ preventScroll: true });
      lastPointer = pointInBoard(event, svg);
      if (event.pointerType === "pen") {
        event.preventDefault();
        penPointer = event.pointerId;
        svg.classList.add("writing");
        status(true);
        if (lastPointer) add(lastPointer);
      }
    }
    function up(event) {
      if (event.pointerId === penPointer) disarm();
    }
    function wheel(event) {
      finish();
      lastPointer = null;
    }
    function visibility() {
      if (document.hidden) disarm();
    }
    function focus(event) {
      if (editable(event.target) || !svg.contains(event.target)) disarm();
    }
    window.addEventListener("keydown", keydown);
    window.addEventListener("keyup", keyup);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", disarm);
    window.addEventListener("blur", disarm);
    window.addEventListener("wheel", wheel, { passive: true });
    document.addEventListener("visibilitychange", visibility);
    document.addEventListener("focusin", focus);
    svg.addEventListener("pointerdown", down);
    return {
      finish: disarm,
      destroy() {
        disarm();
        window.removeEventListener("keydown", keydown);
        window.removeEventListener("keyup", keyup);
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
        window.removeEventListener("pointercancel", disarm);
        window.removeEventListener("blur", disarm);
        window.removeEventListener("wheel", wheel);
        document.removeEventListener("visibilitychange", visibility);
        document.removeEventListener("focusin", focus);
        svg.removeEventListener("pointerdown", down);
      }
    };
  }

  // site/notes/app.js
  var root = document.createElement("section");
  root.id = "notes-root";
  root.hidden = true;
  document.body.append(root);
  var dialog = document.createElement("dialog");
  dialog.id = "notes-dialog";
  document.body.append(dialog);
  var library = emptyLibrary();
  var savedRaw = null;
  var blocked = false;
  var dirty = false;
  var conflict = false;
  var opened = false;
  var selectedFolder = null;
  var selectedNote = null;
  var query = "";
  var drawing;
  var saveTimer;
  var tool = "pen";
  var color = COLORS[0];
  var width = 3;
  var redo = [];
  var penColor = COLORS[0];
  var markerColor = COLORS[4];
  var esc = (value) => String(value).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  var note = () => library.notes.find((n) => n.id === selectedNote);
  try {
    savedRaw = localStorage.getItem(KEY);
    if (savedRaw) library = validate(JSON.parse(savedRaw));
  } catch {
    blocked = true;
  }
  function message(text, error = false) {
    const host = root.querySelector("#notes-save-state");
    if (host) {
      host.textContent = text;
      host.classList.toggle("error", error);
    }
  }
  function persist() {
    clearTimeout(saveTimer);
    if (!dirty) return !blocked;
    try {
      if (blocked || conflict)
        throw new Error(
          conflict ? "Notes changed in another tab. Export your unsaved notes, then reload to use the other version." : "Saved notes could not be loaded. Restore a valid notes backup to continue."
        );
      if (localStorage.getItem(KEY) !== savedRaw) {
        conflict = true;
        throw new Error(
          "Notes changed in another tab. Export your unsaved notes, then reload."
        );
      }
      validate(library);
      const raw = JSON.stringify(library);
      localStorage.setItem(KEY, raw);
      savedRaw = raw;
      dirty = false;
      message("Saved on this device");
      return true;
    } catch (error) {
      message(
        `Not saved \xB7 ${error.message} Export a backup to keep your work.`,
        true
      );
      return false;
    }
  }
  function changed(immediate = false) {
    if (note()) note().updated = Date.now();
    dirty = true;
    message("Saving\u2026");
    clearTimeout(saveTimer);
    if (immediate) persist();
    else saveTimer = setTimeout(persist, 400);
  }
  function stopDrawing() {
    drawing?.destroy();
    drawing = null;
  }
  function selectNote(id) {
    stopDrawing();
    persist();
    selectedNote = id;
    redo = [];
    render();
  }
  function selectFolder(id) {
    stopDrawing();
    persist();
    selectedFolder = id;
    selectedNote = null;
    query = "";
    redo = [];
    render();
  }
  function openNotes() {
    opened = true;
    root.hidden = false;
    document.body.classList.add("notes-open");
    render();
    bridge();
  }
  function closeNotes() {
    stopDrawing();
    if (!persist() && dirty && !confirm(
      "Some notes have not saved. Leave notes anyway? Export a backup first to keep them."
    ))
      return false;
    opened = false;
    root.hidden = true;
    document.body.classList.remove("notes-open");
    return true;
  }
  function bridge() {
    const nav = document.querySelector("#app .sidebar nav");
    if (!nav) return;
    let button = nav.querySelector("#lint-notes-nav");
    if (!button) {
      button = document.createElement("button");
      button.id = "lint-notes-nav";
      button.className = "nav-item";
      button.innerHTML = '<span class="icon" aria-hidden="true">\u25A7</span><span>Notes</span>';
      nav.insertBefore(button, nav.querySelector(".nav-heading"));
    }
    button.classList.toggle("active", opened);
    button.setAttribute("aria-current", opened ? "page" : "false");
    if (opened)
      nav.querySelectorAll(".nav-item.active:not(#lint-notes-nav)").forEach((el) => el.classList.remove("active"));
  }
  new MutationObserver(bridge).observe(document.querySelector("#app"), {
    childList: true,
    subtree: true
  });
  document.querySelector("#app").addEventListener(
    "click",
    (event) => {
      if (event.target.closest("#lint-notes-nav")) {
        event.preventDefault();
        event.stopPropagation();
        openNotes();
        return;
      }
      if (opened && event.target.closest(
        "[data-page],[data-deck],.brand,#new-folder,#new-deck,#export,#import,[data-folder]"
      ) && !closeNotes()) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    },
    true
  );
  bridge();
  function folderTree(parent = null) {
    return library.folders.filter((f) => f.parentId === parent).map(
      (f) => `<div class="notes-folder-row"><button data-nfolder="${esc(f.id)}" class="${selectedFolder === f.id ? "chosen" : ""}"><span aria-hidden="true">\u25B1</span><span>${esc(f.name)}</span></button><button data-manage-folder="${esc(f.id)}" aria-label="Manage notes folder ${esc(f.name)}">\xB7\xB7\xB7</button></div><div class="notes-subfolders">${folderTree(f.id)}</div>`
    ).join("");
  }
  function visibleNotes() {
    return library.notes.filter(
      (n) => (selectedFolder === "all" || n.folderId === selectedFolder) && (!query || `${n.title} ${n.text}`.toLowerCase().includes(query.toLowerCase()))
    ).sort((a, b) => b.updated - a.updated);
  }
  function render() {
    stopDrawing();
    const current = note();
    root.innerHTML = `<header class="notes-topbar"><span>Workspace <span>/</span> <strong>Notes</strong></span><span class="notes-local-label">A SPACE TO THINK ON PAPER</span></header><div class="notes-page"><div class="notes-heading"><div><div class="eyebrow">MAKE YOURSELF SOME ROOM</div><h1>Your thoughts,<br><em>in good company.</em></h1><p>Write it down. Sketch it out. Make it yours.</p></div><div class="notes-heading-actions"><button class="outline" id="notes-new-folder" ${blocked ? "disabled" : ""}>+ Folder</button><button class="primary" id="notes-new-note" ${blocked ? "disabled" : ""}>+ New note</button></div></div><div id="notes-save-state" class="notes-save-state ${blocked || conflict ? "error" : ""}" role="status">${blocked ? "Saved notes could not be loaded. Original data is preserved. Restore a valid notes backup." : conflict ? "Notes changed in another tab. Export your changes before reloading." : dirty ? "Unsaved changes" : "Saved on this device"}</div><div class="notes-layout"><aside class="notes-library" aria-label="Notes folders"><div class="notes-library-title">NOTEBOOKS <span>${library.notes.length}</span></div><button class="notes-root-folder ${selectedFolder === "all" ? "chosen" : ""}" data-nfolder="all">All notes <span>${library.notes.length}</span></button><button class="notes-root-folder ${selectedFolder === null ? "chosen" : ""}" data-nfolder="root">Unfiled notes</button><div class="notes-folder-tree">${folderTree()}</div><div class="notes-backup"><button id="notes-export">Export notes backup</button><button id="notes-import">Restore notes backup</button></div></aside><section class="notes-browser"><div class="notes-browser-heading"><div><h2>${current ? esc(current.title) : selectedFolder === "all" ? "All notes" : esc(folderPath(library, selectedFolder))}</h2><p>${current ? "A little space for a bigger idea." : "Choose a note, or start with a blank page."}</p></div>${current ? '<button class="outline" id="notes-back">\u2190 Notes list</button>' : ""}</div>${current ? editorMarkup(current) : '<input id="notes-search" type="search" aria-label="Search notes in this folder" placeholder="Search these notes\u2026"><div id="notes-list" class="notes-list"></div>'}</section></div></div>`;
    root.querySelectorAll("[data-nfolder]").forEach(
      (el) => el.onclick = () => selectFolder(
        el.dataset.nfolder === "root" ? null : el.dataset.nfolder
      )
    );
    root.querySelectorAll("[data-manage-folder]").forEach(
      (el) => el.onclick = () => folderDialog(el.dataset.manageFolder)
    );
    root.querySelector("#notes-new-folder").onclick = () => createFolder();
    root.querySelector("#notes-new-note").onclick = () => {
      const created = makeNote(selectedFolder === "all" ? null : selectedFolder);
      library.notes.push(created);
      selectedNote = created.id;
      changed(true);
      render();
      root.querySelector("#note-title").select();
    };
    root.querySelector("#notes-export").onclick = exportNotes;
    root.querySelector("#notes-import").onclick = importNotes;
    if (current) bindEditor(current);
    else {
      const input = root.querySelector("#notes-search");
      input.value = query;
      input.oninput = () => {
        query = input.value;
        renderList();
      };
      renderList();
    }
  }
  function renderList() {
    const items = visibleNotes();
    root.querySelector("#notes-list").innerHTML = items.length ? items.map(
      (n) => `<button class="note-tile" data-note="${esc(n.id)}"><span class="note-tile-icon" aria-hidden="true">\u25A7</span><strong>${esc(n.title)}</strong><span class="note-excerpt">${esc(n.text.slice(0, 100) || (n.strokes.length ? "A thought, drawn by hand." : "A blank page, full of possibility."))}</span><span class="note-tile-footer">${esc(folderPath(library, n.folderId))}<span>${new Date(n.updated).toLocaleDateString(void 0, { month: "short", day: "numeric" })}</span></span></button>`
    ).join("") : `<div class="notes-empty"><span aria-hidden="true">\u2727</span><h3>${query ? "No matching notes" : "Start with a little thought."}</h3><p>${query ? "Try another search." : "Create your first note, then add words and drawings."}</p><button class="primary" id="notes-empty-new">+ New note</button></div>`;
    root.querySelectorAll("[data-note]").forEach((el) => el.onclick = () => selectNote(el.dataset.note));
    root.querySelector("#notes-empty-new")?.addEventListener(
      "click",
      () => root.querySelector("#notes-new-note").click()
    );
  }
  function editorMarkup(current) {
    return `<div class="note-editor"><div class="note-actions"><label>Folder<select id="note-folder" aria-label="Note folder">${folderOptions(current.folderId)}</select></label><button class="notes-delete" id="note-delete">Delete note</button></div><div class="note-paper"><label class="sr-only" for="note-title">Note title</label><input id="note-title" class="note-title" maxlength="200" value="${esc(current.title)}" placeholder="Untitled note"><div class="note-date">${new Date(current.created).toLocaleDateString(void 0, { month: "long", day: "numeric", year: "numeric" })} <span>\u2022</span> YOUR SPACE TO THINK</div><label class="sr-only" for="note-text">Note text</label><textarea id="note-text" class="note-text" placeholder="Start writing here\u2026">${esc(current.text)}</textarea><div class="notes-ink-toolbar" role="toolbar" aria-label="Drawing tools"><div class="ink-tools"><button data-ink="pen" aria-pressed="${tool === "pen"}">\u270E Pen</button><button data-ink="highlighter" aria-pressed="${tool === "highlighter"}">\u25B0 Highlighter</button></div><div class="ink-colors" aria-label="Ink color">${COLORS.map((c, i) => `<button class="ink-color ${c === color ? "selected" : ""}" style="--ink:${c}" data-color="${c}" aria-label="${["Graphite", "Blue", "Red", "Green", "Yellow", "Pink"][i]} ink" aria-pressed="${c === color}"></button>`).join("")}</div><label class="ink-size-label">Size<input id="ink-size" aria-label="Stroke size" type="range" min="${tool === "pen" ? 1 : 12}" max="${tool === "pen" ? 10 : 40}" value="${width}"><output id="ink-size-value">${width}</output></label><div class="ink-history"><button id="ink-undo" aria-label="Undo drawing" ${!current.strokes.length ? "disabled" : ""}>\u21B6</button><button id="ink-redo" aria-label="Redo drawing" ${!redo.length ? "disabled" : ""}>\u21B7</button><button id="ink-clear" ${!current.strokes.length ? "disabled" : ""}>Clear</button></div></div><div class="ink-instruction"><span id="ink-mode">SCROLL MODE</span><span>Hold <kbd>Space</kbd> + move to draw. Release to scroll.</span></div><div class="note-artboard" id="note-artboard"><svg id="note-canvas" viewBox="0 0 ${WIDTH} ${current.pageHeight || HEIGHT}" style="aspect-ratio:${WIDTH}/${current.pageHeight || HEIGHT}" tabindex="0" role="img" aria-label="Bounded drawing area. Hold Space and move your pointer to draw." xmlns="http://www.w3.org/2000/svg"><defs><pattern id="note-dot-grid" width="25" height="25" patternUnits="userSpaceOnUse"><circle cx="12.5" cy="12.5" r="1" fill="#b8c3ac" opacity="0.4"/></pattern></defs><rect width="${WIDTH}" height="${current.pageHeight || HEIGHT}" fill="url(#note-dot-grid)"/></svg><span class="artboard-caption">YOUR DRAWING SPACE</span></div><p class="note-paper-hint">Drawing stays inside the dotted outline. Click the drawing area to leave the text editor, then hold Space. Pen/stylus contact also draws; touch gestures scroll.</p></div></div>`;
  }
  function bindEditor(current) {
    root.querySelector("#notes-back").onclick = () => selectNote(null);
    root.querySelector("#note-title").oninput = (event) => {
      current.title = event.target.value.trim() || "Untitled note";
      changed();
      root.querySelector(".notes-browser-heading h2").textContent = current.title;
    };
    root.querySelector("#note-text").oninput = (event) => {
      current.text = event.target.value;
      changed();
    };
    root.querySelector("#note-folder").onchange = (event) => {
      current.folderId = event.target.value || null;
      changed(true);
    };
    root.querySelector("#note-delete").onclick = () => {
      if (!confirm(`Delete \u201C${current.title}\u201D and its drawings?`)) return;
      stopDrawing();
      library.notes = library.notes.filter((n) => n.id !== current.id);
      selectedNote = null;
      dirty = true;
      persist();
      render();
    };
    const svg = root.querySelector("#note-canvas");
    current.strokes.forEach((s) => svg.append(strokeElement(s)));
    function buttons() {
      root.querySelector("#ink-undo").disabled = !current.strokes.length;
      root.querySelector("#ink-redo").disabled = !redo.length;
      root.querySelector("#ink-clear").disabled = !current.strokes.length;
    }
    function redraw() {
      svg.querySelectorAll("path[data-tool]").forEach((p) => p.remove());
      current.strokes.forEach((s) => svg.append(strokeElement(s)));
      buttons();
    }
    drawing = attachDrawing(svg, {
      getNote: () => current,
      getTool: () => ({ tool, color, width }),
      active: () => opened && selectedNote === current.id && !dialog.open && !document.querySelector("#modal[open]"),
      changed: () => {
        redo = [];
        changed(true);
        buttons();
      },
      status: (writing) => {
        const label = root.querySelector("#ink-mode");
        if (label) {
          label.textContent = writing ? "DRAWING \xB7 RELEASE SPACE TO STOP" : "SCROLL MODE";
          label.classList.toggle("armed", writing);
        }
      }
    });
    root.querySelectorAll("[data-ink]").forEach(
      (el) => el.onclick = () => {
        drawing.finish();
        tool = el.dataset.ink;
        color = tool === "pen" ? penColor : markerColor;
        width = tool === "pen" ? 3 : 24;
        root.querySelectorAll("[data-ink]").forEach((b) => b.setAttribute("aria-pressed", String(b === el)));
        root.querySelectorAll("[data-color]").forEach((b) => {
          b.classList.toggle("selected", b.dataset.color === color);
          b.setAttribute("aria-pressed", String(b.dataset.color === color));
        });
        const range = root.querySelector("#ink-size");
        range.min = tool === "pen" ? 1 : 12;
        range.max = tool === "pen" ? 10 : 40;
        range.value = width;
        root.querySelector("#ink-size-value").textContent = width;
      }
    );
    root.querySelectorAll("[data-color]").forEach(
      (el) => el.onclick = () => {
        drawing.finish();
        color = el.dataset.color;
        if (tool === "pen") penColor = color;
        else markerColor = color;
        root.querySelectorAll("[data-color]").forEach((b) => {
          b.classList.toggle("selected", b === el);
          b.setAttribute("aria-pressed", String(b === el));
        });
      }
    );
    root.querySelector("#ink-size").oninput = (event) => {
      drawing.finish();
      width = Number(event.target.value);
      root.querySelector("#ink-size-value").textContent = width;
    };
    root.querySelector("#ink-undo").onclick = () => {
      drawing.finish();
      if (current.strokes.length) redo.push(current.strokes.pop());
      changed(true);
      redraw();
    };
    root.querySelector("#ink-redo").onclick = () => {
      drawing.finish();
      if (redo.length) current.strokes.push(redo.pop());
      changed(true);
      redraw();
    };
    root.querySelector("#ink-clear").onclick = () => {
      if (confirm("Clear all drawings on this note? Text will stay unchanged.")) {
        drawing.finish();
        current.strokes = [];
        redo = [];
        changed(true);
        redraw();
      }
    };
  }
  function folderOptions(selected) {
    return `<option value="">Unfiled notes</option>${library.folders.map((f) => `<option value="${esc(f.id)}" ${selected === f.id ? "selected" : ""}>${esc(folderPath(library, f.id))}</option>`).join("")}`;
  }
  function showDialog(html) {
    drawing?.finish();
    dialog.innerHTML = html;
    dialog.querySelectorAll("[data-close]").forEach((b) => b.onclick = () => dialog.close());
    if (!dialog.open) dialog.showModal();
  }
  function createFolder(parent = selectedFolder === "all" ? null : selectedFolder) {
    showDialog(
      `<form><h2>New notes folder</h2><label>Name<input name="name" required maxlength="100" autofocus placeholder="e.g. Lecture notes"></label><label>Parent folder<select name="parent" aria-label="Parent notes folder">${folderOptions(parent)}</select></label><div class="dialog-actions"><button type="button" class="outline" data-close>Cancel</button><button class="primary">Create folder</button></div></form>`
    );
    dialog.querySelector("form").onsubmit = (event) => {
      event.preventDefault();
      const data = new FormData(event.target);
      const name = data.get("name").trim();
      if (!name) return;
      const folder = { id: uid(), name, parentId: data.get("parent") || null };
      library.folders.push(folder);
      dirty = true;
      persist();
      dialog.close();
      selectFolder(folder.id);
    };
  }
  function folderDialog(id) {
    const folder = library.folders.find((f) => f.id === id);
    showDialog(
      `<form><h2>Folder settings</h2><label>Name<input name="name" required maxlength="100" value="${esc(folder.name)}"></label><div class="dialog-actions"><button type="button" class="outline" id="notes-subfolder">+ Subfolder</button><button class="primary">Save folder</button><button type="button" class="outline" data-close>Cancel</button></div></form><div class="danger-zone"><p>Removing a folder moves its notes and subfolders up one level.</p><button class="danger" id="notes-remove-folder">Remove folder</button></div>`
    );
    dialog.querySelector("form").onsubmit = (event) => {
      event.preventDefault();
      const name = new FormData(event.target).get("name").trim();
      if (!name) return;
      folder.name = name;
      dirty = true;
      persist();
      dialog.close();
      render();
    };
    dialog.querySelector("#notes-subfolder").onclick = () => createFolder(id);
    dialog.querySelector("#notes-remove-folder").onclick = () => {
      removeFolder(library, id);
      dirty = true;
      persist();
      dialog.close();
      selectFolder(folder.parentId);
    };
  }
  function exportNotes() {
    drawing?.finish();
    if (blocked) {
      message(
        "Original notes could not be loaded; refusing to export an empty replacement.",
        true
      );
      return;
    }
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(library, null, 2)], { type: "application/json" })
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = `Lint-notes-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function importNotes() {
    drawing?.finish();
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json,application/json";
    input.hidden = true;
    document.body.append(input);
    input.oncancel = () => input.remove();
    input.onchange = async () => {
      try {
        const file = input.files[0];
        if (!file) return;
        if (file.size > 15 * 1024 * 1024)
          throw new Error("Notes backups must be smaller than 15 MB.");
        const next = validate(JSON.parse(await file.text()));
        if (!confirm(
          `Replace all notes and notes folders with ${next.notes.length} notes from this backup? Flashcards are unaffected.`
        ))
          return;
        const raw = JSON.stringify(next);
        localStorage.setItem(KEY, raw);
        library = next;
        savedRaw = raw;
        dirty = false;
        blocked = false;
        conflict = false;
        selectedNote = null;
        selectedFolder = "all";
        render();
      } catch (error) {
        message(error.message, true);
      } finally {
        input.remove();
      }
    };
    input.click();
  }
  window.addEventListener("beforeunload", (event) => {
    drawing?.finish();
    if (!persist() && dirty) {
      event.preventDefault();
      event.returnValue = "";
    }
  });
  window.addEventListener("pagehide", () => {
    drawing?.finish();
    persist();
  });
  window.addEventListener("storage", (event) => {
    if (event.key !== KEY) return;
    if (dirty || opened && selectedNote) {
      conflict = true;
      message(
        "Notes changed in another tab. Export your version before reloading.",
        true
      );
      return;
    }
    try {
      library = event.newValue ? validate(JSON.parse(event.newValue)) : emptyLibrary();
      savedRaw = event.newValue;
      blocked = false;
      if (opened) render();
    } catch {
      blocked = true;
      if (opened) render();
    }
  });
})();
